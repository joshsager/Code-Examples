This is a place to perfrom code and design experiments related to the project. This keeps the project files clean while allowing a place for concepts to be proven before committing in the project.
